================Assignment Details===================


Question 1:

  https://gist.github.com/manojmj92/54ac74bed683c3175aa8c9700cffaa4e
  Assignment solution available in 'news_feed' folder (Its the complete rails app).

  Things covered:
  building rails with requirement
  written rspec unit test cases.

  Note: Used rails 5.2.0 where bigint is default version for primary key id. This is not changed.



Question 2:

  https://gist.github.com/manojmj92/3fd871e8dd7eb771fd55a51b59097390
  Assignment solution available in 'order_app' folder.

