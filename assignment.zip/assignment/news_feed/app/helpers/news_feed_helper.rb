module NewsFeedHelper
end
