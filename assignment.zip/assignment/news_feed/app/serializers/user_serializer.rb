class UserSerializer < BaseSerializer
  attributes :type, :name
end
