# README

This README would normally document whatever steps are necessary to get the
application up and running.

System Details

* Ruby version : 2.4.1.    Rails version: 5.2.0.  Database: Postgresql(1.1.4)

Note: rails 5.2.0 has default bigint as column type for primary key id.

Setup
* Prerequisite: Rails installed, postgresql installed

* clone the zip file in the folder.

* install the required gems by running 'bundle install'

* Database initialization: rake db:create db:migrate

* Run the rails service: rails s -p port_number

* visit localhost:port_number/news_feed.json 




Testing Details:
 
* Used rspec for unit testcases.

* run the testcase by command 'rspec'
