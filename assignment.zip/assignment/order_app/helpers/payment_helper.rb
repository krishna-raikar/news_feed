module PaymentHelper
  def process_payment(params)
    payment_status = true
    error_message  = ""

    # Get credit card object from ActiveMerchant
    credit_card = ActiveMerchant::Billing::CreditCard.new(card_params(params))

    # Check if card is valid
    if credit_card.valid?
      response = place_order!(credit_card, params)
      if !response.success?
        payment_status = false
        error_message = "We couldn't process your credit card"
      end
    else
      payment_status = false
      error_message  = "Your credit card seems to be invalid"
    end
    [payment_status, error_message]
  end

  # Prepare card params to be send to active merchant.
  def card_params(params)
    card_type = get_card_type(params[:card_info][:card_number])
    { 
      number: params[:card_info][:card_number],
      month: params[:card_info][:card_expiration_month],
      year: params[:card_info][:card_expiration_year],
      verification_value: params[:card_info][:cvv],
      first_name: params[:card_info][:card_first_name],
      last_name: params[:card_info][:card_last_name],
      type: card_type
    }
  end

  # Accepts card number and return type of card.
  def get_card_type(card_number)
    length = card_number.length
    if length == 15 && number =~ /^(34|37)/
      "AMEX"
    elsif length == 16 && number =~ /^6011/
      "Discover"
    elsif length == 16 && number =~ /^5[1-5]/
      "MasterCard"
    elsif (length == 13 || length == 16) && number =~ /^4/
      "Visa"
    else
      "Unknown"
    end
  end

  private 

  # place purchase request
  def place_order!(credit_card, params)
    options = { address: {}, billing_address: billing_address(params) }
    # Make the purchase through ActiveMerchant
    response = PAYMENT_GATEWAY.purchase(@order.charge_amount, credit_card, options)    
  end

  # Prepare billing address params
  def billing_address(params)
    { 
      name: "#{params[:billing_first_name]} #{params[:billing_last_name]}",
      address1: params[:billing_address_line_1],
      city: params[:billing_city], state: params[:billing_state],
      country: 'US',zip: params[:billing_zip],
      phone: params[:billing_phone] 
    }
  end
end