# Establish connection to ActiveMerchant
PAYMENT_GATEWAY = ActiveMerchant::Billing::AuthorizeNetGateway.new(
  login: ENV["AUTHORIZE_LOGIN"],
  password: ENV["AUTHORIZE_PASSWORD"]
)