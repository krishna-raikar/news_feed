class OrdersController < ApplicationController
  include PaymentHelper

  before_action :get_cart

  # process order
  def create
    @order = Order.new(order_params)
    @order.load_cart_items @cart

    payment_status, error_message = process_payment(params)

    if payment_status
      @order.processed
      if @order.save_order!
        flash[:success] = "You successfully ordered!"
        redirect_to confirmation_orders_path
      else
        @order.errors.add(:error, error_message)
        flash[:error] = "There was a problem processing your order. Please try again."
        render :new
      end
    else
      @order.errors.add(:error, error_message)
      flash[:error] = "There was a problem processing your order. Please try again."
      render :new
    end
  end

  private

  def order_params
    params.require(:order).permit!
  end

  def get_cart
    @cart = Cart.find(session[:cart_id])
  rescue ActiveRecord::RecordNotFound
  end
end