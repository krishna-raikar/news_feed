class Order < ActiveRecord::Base

  attr_attributes :total
  attr_accessor :billing_email

  # set required fields for order.
  def initialize(params)
    self.billing_email = params[:billing_email]
    set_shipping_and_order_total(params)
  end

  # Add shipping and tax to order total
  def set_shipping_and_order_total(params)
    case params[:order][:shipping_method]
    when 'ground'
      self.total = (self.taxed_total).round(2)
    when 'two-day'
      self.total = self.taxed_total + (15.75).round(2)
    when 'overnight'
      self.total = self.taxed_total + (25).round(2)
    end
  end

  # change order status processed
  def processed
    self.order_status = 'processed'
  end

  # Change amount.
  def change_amount
    (self.total.to_f * 100).to_i
  end  

  # Load the items from cart to order
  def load_cart_items(cart)
    cart.ordered_items.each do |item|
      self.ordered_items << item
    end
  end

  # remove the card and send the confirmation email to the billing email.
  def save_order!
    Cart.destroy(session[:cart_id])
    # send order confirmation email
    OrderMailer.order_confirmation(self.billing_email, session[:order_id]).deliver
    return true
  end
end